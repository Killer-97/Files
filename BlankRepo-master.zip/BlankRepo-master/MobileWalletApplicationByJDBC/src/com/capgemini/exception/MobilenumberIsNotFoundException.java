package com.capgemini.exception;

public class MobilenumberIsNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1157977180264087291L;

	public MobilenumberIsNotFoundException(String msg)
	{
		super(msg);
	}
}
